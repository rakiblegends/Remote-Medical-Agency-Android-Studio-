package com.example.remotemedicalagency;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class CategoryFragment extends Fragment {
    Button neurologist,gynecologist,cardiologist,dermatologist,psychiatrist,orthopaedics;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_category, container, false);
        getActivity().setTitle("Doctors Category");
        neurologist = view.findViewById(R.id.neurologist);
        gynecologist = view.findViewById(R.id.gynecologist);
        cardiologist = view.findViewById(R.id.cardiologist);
        dermatologist = view.findViewById(R.id.dermatologist);
        psychiatrist = view.findViewById(R.id.psychiatrist);
        orthopaedics = view.findViewById(R.id.orthopaedics);

        gynecologist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), DoctorsList.class);
                i.putExtra("message", "gynecologist");
                startActivity(i);
            }
        });

        neurologist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), DoctorsList.class);
                i.putExtra("message", "neurologist");
                startActivity(i);
            }
        });
        cardiologist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), DoctorsList.class);
                i.putExtra("message", "cardiologist");
                startActivity(i);
            }
        });
        dermatologist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), DoctorsList.class);
                i.putExtra("message", "dermatologist");
                startActivity(i);
            }
        });
        psychiatrist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), DoctorsList.class);
                i.putExtra("message", "psychiatrist");
                startActivity(i);
            }
        });
        orthopaedics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), DoctorsList.class);
                i.putExtra("message", "orthopaedics");
                startActivity(i);
            }
        });

        return view;
    }
}