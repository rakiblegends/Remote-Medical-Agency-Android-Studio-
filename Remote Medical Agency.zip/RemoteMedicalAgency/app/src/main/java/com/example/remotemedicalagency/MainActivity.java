package com.example.remotemedicalagency;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class MainActivity extends AppCompatActivity{
    EditText username;
    EditText password;
    Button loginButton,signupbutton,doctorbtn;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DB = new DBHelper(this);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        doctorbtn = findViewById(R.id.doctor);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameD = username.getText().toString();
                String passwordD = password.getText().toString();
                Boolean checkpointing = DB.checkUserLogin(usernameD,passwordD);
                if(checkpointing){
                    Intent intent =new Intent(getApplicationContext(),login.class);
                    startActivity(intent);
                    Toast.makeText(getApplicationContext(), "Login Successfull!", Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(getApplicationContext(), "Wrong Username and Password!", Toast.LENGTH_LONG).show();
                }
            }
        });

        signupbutton = findViewById(R.id.sign_up);
        signupbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), signup.class);
                startActivity(i);
            }
        });

        doctorbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), DoctorLogin.class);
                startActivity(i);
            }
        });
    }
}