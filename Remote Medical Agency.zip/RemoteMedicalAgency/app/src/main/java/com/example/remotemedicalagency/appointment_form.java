package com.example.remotemedicalagency;


// ReservationFormActivity.java
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class appointment_form extends AppCompatActivity {

    private EditText editTextName, editTextEmail,editTextsymp,editTextDate;
    private Button btnReserve;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent2 = getIntent();
        setContentView(R.layout.activity_appointment_form);
        // Initialize views
        editTextName = findViewById(R.id.name);
        editTextEmail = findViewById(R.id.email);
        editTextsymp = findViewById(R.id.sid);
        editTextDate = findViewById(R.id.datee);
        btnReserve = findViewById(R.id.appoint_btn);

        DB = new DBHelper(this);

        // Set click listener for reserve button
        btnReserve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get user input
                String name = editTextName.getText().toString().trim();
                String email = editTextEmail.getText().toString().trim();
                String symp = editTextsymp.getText().toString().trim();
                String date = editTextDate.getText().toString().trim();
                // Validate input
                if (name.isEmpty() || email.isEmpty()) {
                    Toast.makeText(appointment_form.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                    return;
                }
                Boolean checkpointing = DB.insertappointdata(name,email,symp,date);
                if(checkpointing){
                    Toast.makeText(appointment_form.this, "Appoint Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent4 =new Intent(getApplicationContext(),login.class);
                    startActivity(intent4);

                }else{
                    Toast.makeText(appointment_form.this, "Appoint Failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
