package com.example.remotemedicalagency;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class reserve extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserve);
    }
}