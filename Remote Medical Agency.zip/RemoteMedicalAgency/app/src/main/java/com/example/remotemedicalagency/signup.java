package com.example.remotemedicalagency;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;
import android.content.Intent;
import java.util.regex.Pattern;

public class signup extends AppCompatActivity {
    boolean isValid(String str){
        if (str.length() < 8) {
            return false;
        }
        if (!Pattern.compile("[A-Z]").matcher(str).find()) {
            return false;
        }

        if (!Pattern.compile("[a-z]").matcher(str).find()) {
            return false;
        }
        if (!Pattern.compile("[^a-zA-Z0-9]").matcher(str).find()) {
            return false;
        }
        if (!Pattern.compile("[0-9]").matcher(str).find()) {
            return false;
        }

        return true;
    }
    EditText username,password,fname,lname,email,age,sid,dept;
    Button register;

    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        fname = findViewById(R.id.f_name);
        lname = findViewById(R.id.l_name);
        email = findViewById(R.id.email);
        age = findViewById(R.id.age);

        register = findViewById(R.id.register);
        DB = new DBHelper(this);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameD = username.getText().toString();
                String passwordD = password.getText().toString();
                String fnameD = fname.getText().toString();
                String lnameD= password.getText().toString();
                String emailD = email.getText().toString();
                String ageD = age.getText().toString();
                if(!isValid(passwordD)) {
                    Toast.makeText(signup.this, "Password must contain Uppercase, Lowercase, Number and Special Characters!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Boolean checkpointing = DB.insertuserdata(usernameD,passwordD,fnameD,lnameD,emailD,ageD);
                if(checkpointing) {
                    Toast.makeText(signup.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(i);
                }
                else
                    Toast.makeText(signup.this, "Username already exist!", Toast.LENGTH_SHORT).show();
            }        });

    }
}