package com.example.remotemedicalagency;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import androidx.annotation.Nullable;


public class DBHelper extends SQLiteOpenHelper {

    public DBHelper(Context context) {
        super(context, "Userdata.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("CREATE TABLE registration(username TEXT primary key, password TEXT, fname TEXT, lname TEXT, email TEXT, age TEXT)");
        DB.execSQL("CREATE TABLE appoint(name TEXT, email TEXT primary key, symp TEXT, dt TEXT)");
        DB.execSQL("CREATE TABLE doctors(username TEXT primary key,password TEXT, email TEXT,fname TEXT, lname TEXT,speciality TEXT,phone TEXT)");
    }
    @Override
    public void onUpgrade(SQLiteDatabase DB, int i, int ii) {
        DB.execSQL("DROP TABLE IF EXISTS registration");
        DB.execSQL("DROP TABLE IF EXISTS appoint");
        DB.execSQL("DROP TABLE IF EXISTS doctors");
        onCreate(DB);
    }
    public Boolean insertuserdata(String username, String password, String fname, String lname, String email, String age)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        contentValues.put("fname", fname);
        contentValues.put("lname", lname);
        contentValues.put("email", email);
        contentValues.put("age", age);
        long result=DB.insert("registration", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    public Boolean insertappointdata(String name, String email, String symp, String dt)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues1 = new ContentValues();
        contentValues1.put("name", name);
        contentValues1.put("email", email);
        contentValues1.put("symp", symp);
        contentValues1.put("dt", dt);
        long result=DB.insert("appoint", null, contentValues1);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }
    public Boolean insertdoctorsdata(String username,String password,String fname,String lname,String email,String speciality,String phone)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues1 = new ContentValues();
        contentValues1.put("username", username);
        contentValues1.put("password", password);
        contentValues1.put("fname", fname);
        contentValues1.put("lname", lname);
        contentValues1.put("email", email);
        contentValues1.put("speciality", speciality);
        contentValues1.put("phone", phone);
        long result=DB.insert("doctors", null, contentValues1);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    public Cursor getappointdata(){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from appoint",null);
        return cursor;
    }
    public Cursor getdoctordata(String spec){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select fname,lname,phone from doctors where speciality='"+ spec +"'",null);
        return cursor;
    }

    public Boolean checkUserLogin(String name,String pass){
        SQLiteDatabase db=this.getWritableDatabase();
        String Query = "Select username, password from registration where username='"+ name +"' and password='"+ pass+"'";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(Query, null);//raw query always holds rawQuery(String Query,select args)
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(cursor!=null && cursor.getCount()>0){
            cursor.close();
            return true;
        }
        else{
            cursor.close();
            return false;
        }
    }

    public Boolean checkdoctorLogin(String name,String pass){
        SQLiteDatabase db=this.getWritableDatabase();
        String Query = "select username, password from doctors where username='"+ name +"' and password='"+ pass+"'";
        Cursor cursor = null;

        try {
            cursor = db.rawQuery(Query, null);//raw query always holds rawQuery(String Query,select args)
        } catch (Exception e) {
            e.printStackTrace();
        }

        if(cursor!=null && cursor.getCount()>0){
            cursor.close();
            return true;
        }
        else{
            cursor.close();
            return false;
        }
    }
}

