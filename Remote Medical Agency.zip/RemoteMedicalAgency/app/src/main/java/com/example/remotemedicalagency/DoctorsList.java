package com.example.remotemedicalagency;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class DoctorsList extends AppCompatActivity {
    RecyclerView recyclerview1;
    ArrayList<String> name,degrees,phone;
    DBHelper DB;
    MyAdapter1 adapter;
    String spec = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctors_list);
        DB = new DBHelper(this);
        name = new ArrayList<>();
        degrees = new ArrayList<>();
        phone = new ArrayList<>();
        spec = getIntent().getStringExtra("message");
        recyclerview1 = findViewById(R.id.recyclerview1);
        adapter = new MyAdapter1(this,name,degrees,phone);
        recyclerview1.setAdapter(adapter);
        recyclerview1.setLayoutManager(new LinearLayoutManager(this));
        displaydata();
    }
    private void displaydata(){
        Cursor cursor = DB.getdoctordata(spec);
        if(cursor.getCount()==0){
            Toast.makeText(this,"No Doctors Exist",Toast.LENGTH_SHORT).show();
            return;
        }else{
            while(cursor.moveToNext()){
                name.add(cursor.getString(0));
                degrees.add(cursor.getString(1));
                phone.add(cursor.getString(2));
            }
        }
    }
}