package com.example.remotemedicalagency;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;
import android.content.Intent;
import java.util.regex.Pattern;

public class doctorsignup extends AppCompatActivity {
    boolean isValid(String str){
        if (str.length() < 8) {
            return false;
        }
        if (!Pattern.compile("[A-Z]").matcher(str).find()) {
            return false;
        }

        if (!Pattern.compile("[a-z]").matcher(str).find()) {
            return false;
        }
        if (!Pattern.compile("[^a-zA-Z0-9]").matcher(str).find()) {
            return false;
        }
        if (!Pattern.compile("[0-9]").matcher(str).find()) {
            return false;
        }

        return true;
    }
    EditText username,password,fname,lname,email,phone;
    Button register;
    String spec;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctorsignup);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        fname = findViewById(R.id.f_name);
        lname = findViewById(R.id.l_name);
        email = findViewById(R.id.email);
        phone = findViewById(R.id.phone);

        register = findViewById(R.id.register);
        DB = new DBHelper(this);
        Spinner spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.specialityin, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Retrieve the selected item
                String selectedItem = parent.getItemAtPosition(position).toString();
                spec = selectedItem;
                // Display the selected item in a toast message
                Toast.makeText(doctorsignup.this, "Selected: " + spec, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameD = username.getText().toString();
                String passwordD = password.getText().toString();
                String fnameD = fname.getText().toString();
                String lnameD= lname.getText().toString();
                String emailD = email.getText().toString();
                String specD = spec;
                String phoneD = phone.getText().toString();
                if(!isValid(passwordD)) {
                    Toast.makeText(doctorsignup.this, "Password must contain Uppercase, Lowercase, Number and Special Characters!", Toast.LENGTH_SHORT).show();
                    return;
                }
                Boolean checkpointing = DB.insertdoctorsdata(usernameD,passwordD,fnameD,lnameD,emailD,specD,phoneD);
                if(checkpointing) {
                    Toast.makeText(doctorsignup.this, "Registration Successful!", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), DoctorLogin.class);
                    startActivity(i);
                }
                else
                    Toast.makeText(doctorsignup.this, "Username already exist!", Toast.LENGTH_SHORT).show();
            }        });

    }
}